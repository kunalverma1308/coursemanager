(function () {

    'use strict';

    angular
        .module('courseApp')
        .config(config);

    config.$inject = ['$routeProvider'];

    function config($routeProvider) {

        $routeProvider

            .when('/', {
                templateUrl: 'app/views/dashboard.html'
            })

            .when('/courses', {
                templateUrl: 'app/views/courses.html',
                controller: 'MainController',
                controllerAs: 'vm'
            })

            .when('/add-course', {
                templateUrl: 'app/views/add-course.html',
                controller: 'MainController',
                controllerAs: 'vm'
            })

            .when('/profile', {
                templateUrl: 'app/views/profile.html',
                controller: 'MainController',
                controllerAs: 'vm'
            })

            .otherwise({
                redirectTo: '/'
            });
    }

})();